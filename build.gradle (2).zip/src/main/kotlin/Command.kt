package industrySim

public interface Command {
    fun execute (args : List<String>) : Boolean
}

abstract class CommandFactory {
    abstract fun get(command: String): Command
}

class CommandExit : Command {
    companion object Factory : CommandFactory()
    {
        override fun get(command: String): Command {
            if (command == )
        }
    }
    override fun execute(args: List<String>): Boolean {
        print ("Exit")
        return true
    }
}

class ConcreteCommandFactory : CommandFactory<Command> {
    override fun create(commandType: String): Command {
        return when (commandType) {
            "exit" -> CommandExit()
            // Add more cases for other command types
            else -> throw IllegalArgumentException("Unknown command type: $commandType")
        }
    }
}

fun processCommand (arguments : String) : Boolean
{
    var continue : Boolean = true
    var args = arguments.split(" ")
    var command: Command? = ConcreteCommandFactory().create(args[0])
    when (args[0])
    {
        "exit" ->
        {
             command = CommandExit1()
        }
        else -> print ("buzz!!!")
    }
    if (command != null)
    {
        return command.execute(args)
    }
}
