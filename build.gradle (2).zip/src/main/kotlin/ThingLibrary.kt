package industrySim

class ThingLibrary
{
    val things: MutableList<Thing> = mutableListOf()
    fun main()
    {
        create()
    }
    fun create ()
    {
        things.add(Thing("Carbon", 25))
        things.add(Thing("Iron", 50))
        things.add(Thing("Steel Block", 150))
        things.add(Thing("Steel Plate", 500))
        things.add(Thing("Steel Sheet", 600))
    }
}