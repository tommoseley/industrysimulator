package industrySim

data class Thing (val name : String, val priceBasis: Int)
